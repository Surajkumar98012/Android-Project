package com.rnz.ggistudentapp.Models;

public class SpaceModel {
    int image;

    public SpaceModel(int image) {
        this.image = image;

    }

    public int getImage() {
        return image;
    }

/*    public void setDate(String date) {
        this.date = date;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }*/

 /*   public String getImage() {
        return announcementtitle;
    }*/

/*    public void setAnnouncementtitle(String announcementtitle) {
        this.announcementtitle = announcementtitle;
    }*/

 /*   public String getAnnouncement() {
        return announcement;
    }*/

    public void setImage(int image) {
        this.image = image;
    }
}



